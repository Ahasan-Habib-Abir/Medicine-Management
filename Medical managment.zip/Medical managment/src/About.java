import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class About implements ActionListener {

    JFrame  f1 = new JFrame();
    JPanel p1 = new JPanel();
    JLabel l1 = new JLabel("MEDI-LIFE -About");
    JLabel l3 = new JLabel();
    JLabel l4 = new JLabel();
    JPanel p2 = new JPanel();

    ImageIcon img = new ImageIcon("Sir.jpg");
    JLabel l11 = new JLabel("", img, JLabel.CENTER);
    ImageIcon img1 = new ImageIcon("Abir.jpg");
    JLabel l12 = new JLabel("", img1, JLabel.CENTER);
    ImageIcon img2 = new ImageIcon("Tonmoy.jpg");
    JLabel l13 = new JLabel("", img2, JLabel.CENTER);
    ImageIcon img3 = new ImageIcon("Sojib.jpg");
    JLabel l14 = new JLabel("", img3, JLabel.CENTER);
    ImageIcon img4 = new ImageIcon("Bashar.jpg");
    JLabel l15 = new JLabel("", img4, JLabel.CENTER);


    JPanel p11= new JPanel();
    JPanel p12 = new JPanel();
    JPanel p13 = new JPanel();
    JPanel p14 = new JPanel();
    JPanel p15 = new JPanel();
    JLabel l5 = new JLabel();
    JLabel l23 = new JLabel();
    JLabel l24 = new JLabel();
    JLabel l25 = new JLabel();
    JLabel l26 = new JLabel();
    JButton b1 = new JButton("BACK");

    About(){

        b1.setBounds(0, 70, 100, 30);
        b1.setFont(new Font("TT",Font.BOLD,20));
        b1.setBackground(new Color(0xE90DD6));
        b1.addActionListener(this);
        f1.add(b1);
        p1.setBounds(0,0,1600,70);
        p1.setBackground(new Color(0xF73FEA74, true));
        l1.setText("MEDI LIFE-About");
        l1.setBounds(800,35,200,50);
        l1.setFont(new Font("",Font.BOLD+Font.ITALIC,50));



        l3.setText("Supervised By ARGHO DAS");
        l3.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l3.setBounds(700,50,700,300);
        l5.setText("Lecturer , Computer Science, AIUB");
        l5.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l5.setBounds(700,80,700,300);
        f1.add(l5);

        l4.setText("Team Members");
        l4.setFont(new Font("MV",Font.ITALIC+Font.BOLD,25));
        l4.setBounds(50,430,300,50);


        p11.setBounds(300,70,300,300);
        p12.setBounds(50,500,300,300);
        l23.setText("AHASAN HABIB, 22-48877-3");
        l23.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l23.setBounds(50,670,700,300);
        f1.add(l23);
        p13.setBounds(400,500,300,300);
        l24.setText("KAMRUL HASAN, 22-48825-3");
        l24.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l24.setBounds(400,670,700,300);
        f1.add(l24);
        p14.setBounds(750,500,300,300);
        l25.setText("MD.SAJIB MONDOL, 22-48824-3");
        l25.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l25.setBounds(750,670,700,300);
        f1.add(l25);
        p15.setBounds(1100,500,300,300);
        l26.setText("ABUL BASHAR SAUROV, 22-48823-3");
        l26.setFont(new Font("MV",Font.ITALIC+Font.BOLD,20));
        l26.setBounds(1100,670,700,300);
        f1.add(l26);
        p11.add(l11);
        p12.add(l12);
        p13.add(l13);
        p14.add(l14);
        p15.add(l15);

        f1.add(p11);
        f1.add(p12);
        f1.add(p13);
        f1.add(p14);
        f1.add(p15);
        f1.add(l3);
        f1.add(l4);
        f1.add(p1);
        f1.add(p2);
        //f1.add(p3);
        p1.add(l1);
        f1.setLayout(null);
        f1.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        f1.setBounds(150,120,1600,900);
        f1.setResizable(false);
        f1.setLocationRelativeTo(null);
        f1.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)  {
        if (e.getSource() == b1) {
            HomePage hp = new HomePage();
            f1.setVisible(false);

        }
    }
}