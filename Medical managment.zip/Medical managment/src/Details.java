public class Details extends Main {


    // Details();
}
