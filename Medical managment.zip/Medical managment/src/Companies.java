import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Companies implements ActionListener {

    JFrame f1 = new JFrame();
    JPanel p1 = new JPanel();
    JLabel l1 = new JLabel("MEDI-LIFE -Companies");
    JLabel l3 = new JLabel();
    JLabel l4 = new JLabel();
    JPanel p2 = new JPanel();

    ImageIcon img = new ImageIcon("1.png");
    JLabel l11 = new JLabel("", img, JLabel.CENTER);
    ImageIcon img1 = new ImageIcon("2.png");
    JLabel l12 = new JLabel("", img1, JLabel.CENTER);
    ImageIcon img2 = new ImageIcon("22..jpg");
    JLabel l13 = new JLabel("", img2, JLabel.CENTER);
    ImageIcon img3 = new ImageIcon("52.jpg");
    JLabel l14 = new JLabel("", img3, JLabel.CENTER);
    ImageIcon img4 = new ImageIcon("10.jpg");
    JLabel l15 = new JLabel("", img4, JLabel.CENTER);

    ImageIcon img5 = new ImageIcon("111.jpg");
    JLabel l16 = new JLabel("", img5, JLabel.CENTER);


    JPanel p11 = new JPanel();
    JPanel p12 = new JPanel();
    JPanel p13 = new JPanel();
    JPanel p14 = new JPanel();
    JPanel p15 = new JPanel();
    JPanel p16 = new JPanel();
    JLabel l5 = new JLabel();
    JLabel l23 = new JLabel();
    JLabel l24 = new JLabel();
    JLabel l25 = new JLabel();
    JLabel l26 = new JLabel();
    JButton b1 = new JButton("BACK");

    Companies() {
        b1.setBounds(0, 70, 100, 30);
        b1.setFont(new Font("TT",Font.BOLD,16));
        b1.setBackground(Color.RED);
        b1.addActionListener(this);
        f1.add(b1);
        p1.setBounds(0, 0, 1600, 70);
        p1.setBackground(new Color(0xF73FEA74, true));
        l1.setText("MEDI LIFE-Companies");
        l1.setBounds(800, 35, 200, 50);
        l1.setFont(new Font("", Font.BOLD + Font.ITALIC, 50));



        l3.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l3.setBounds(700, 50, 700, 300);

        l5.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l5.setBounds(700, 80, 700, 300);
        f1.add(l5);
        p16.setBounds(900, 80, 300, 300);

        l4.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 25));
        l4.setBounds(50, 430, 300, 50);


        p11.setBounds(300, 70, 300, 300);
        p12.setBounds(50, 500, 300, 300);

        l23.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l23.setBounds(50, 670, 700, 300);
        f1.add(l23);
        p13.setBounds(450, 500, 300, 300);

        l24.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l24.setBounds(400, 670, 700, 300);
        f1.add(l24);
        p14.setBounds(800, 500, 300, 300);

        l25.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l25.setBounds(750, 670, 700, 300);
        f1.add(l25);
        p15.setBounds(1150, 500, 300, 300);

        l26.setFont(new Font("MV", Font.ITALIC + Font.BOLD, 20));
        l26.setBounds(1100, 670, 700, 300);
        f1.add(l26);
        p11.add(l11);
        p12.add(l12);
        p13.add(l13);
        p14.add(l14);
        p15.add(l15);
        p16.add(l16);

        f1.add(p11);
        f1.add(p12);
        f1.add(p13);
        f1.add(p14);
        f1.add(p15);
        f1.add(p16);
        f1.add(l3);
        f1.add(l4);
        f1.add(p1);
        f1.add(p2);
        //f1.add(p3);
        p1.add(l1);
        f1.setLayout(null);
        f1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f1.setBounds(150, 120, 1600, 900);
        f1.setResizable(false);
        f1.setLocationRelativeTo(null);
        f1.add(b1);
        f1.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            HomePage hp = new HomePage();
            f1.setVisible(false);

        }
    }
}
